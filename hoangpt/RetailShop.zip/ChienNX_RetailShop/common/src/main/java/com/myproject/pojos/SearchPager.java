package com.myproject.pojos;

import java.util.List;

public class SearchPager<T> {
	private long currentPage;
	private long maxResults;
	private long pageSize = 5;
	private List<T> currentResults;
	
	public SearchPager(){}
	public SearchPager(long pageSize, long currentPage, long maxResults, List<T> currentResults){
		this.currentPage = currentPage;
		this.maxResults = maxResults;
		this.currentResults = currentResults;
		this.pageSize = pageSize;
	}
	
	public long getTotalPages(){
		return (long) Math.ceil((double) maxResults / pageSize);
	}
	
	public long getCurrentPage(){
		return currentPage;
	}
	
	public long getMaxResults(){
		return maxResults;
	}
	
	public List<T> getCurrentResults(){
		return currentResults;
	}
}
