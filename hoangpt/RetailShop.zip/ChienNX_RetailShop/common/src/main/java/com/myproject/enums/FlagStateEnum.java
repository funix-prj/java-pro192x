package com.myproject.enums;

public enum FlagStateEnum {
	ON (1, true),
	OFF (0, false);
	
	public final int INT_VAL;
	public final boolean BOOLEAN_VAL;
	private FlagStateEnum(int intVal, boolean booleanVal){
		this.INT_VAL = intVal;
		this.BOOLEAN_VAL = booleanVal;
	}
	
	public static FlagStateEnum valueOfInt(Integer val){
		for(FlagStateEnum e : FlagStateEnum.values()){
			if(e.INT_VAL == val.intValue())
				return e;
		}
		return null;
	}
	
	public static FlagStateEnum valueOfBool(boolean val){
		if(val) return FlagStateEnum.ON;
		else return FlagStateEnum.OFF;
	}
}
