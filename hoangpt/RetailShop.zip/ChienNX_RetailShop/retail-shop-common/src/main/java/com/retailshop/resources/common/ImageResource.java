package com.retailshop.resources.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.retailshop.biz.service.IProductService;
import com.retailshop.biz.service.IWhitelabelService;

@RestController
@RequestMapping(value="/productimage")
public class ImageResource {
	private Logger logger = LoggerFactory.getLogger(ImageResource.class);
	
	@Autowired
	private IWhitelabelService whitelableService;
	@Autowired
	private IProductService productService;
	
	@RequestMapping(value="/upload", method=RequestMethod.POST)
	public boolean uploadImage(@RequestParam("file") MultipartFile file, @RequestParam("pid") Long productId){
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
	
		try {
			if (file.isEmpty()) return false;
			String dirPath = "E:\\products\\images\\"+whitelableService.getLoginWlCode();
			File dir = new File(dirPath);
			if(!dir.exists()) dir.mkdirs();
			String originalName = file.getOriginalFilename();
			String extension = originalName.substring(originalName.lastIndexOf("."));
			String imageName = String.valueOf(productId)+extension;
			bis = new BufferedInputStream(file.getInputStream());
			bos = new BufferedOutputStream(new FileOutputStream(dirPath+File.separator+imageName));
			byte [] buffer = new byte[256];
			while(bis.read(buffer) != -1){
				bos.write(buffer);
			}
			
			productService.updateProductImageLink(imageName, productId, whitelableService.getLoginWlCode());
			
			return true;
        } catch (Exception e) {
        	logger.error(e.getMessage(), e);
        	return false;
        } finally{
        	try{
        		if(bos != null) bos.close();
        		if(bis != null) bis.close();
        	}catch(Exception e){
        		logger.error(e.getMessage(), e);
        	}
        }
	}
}
