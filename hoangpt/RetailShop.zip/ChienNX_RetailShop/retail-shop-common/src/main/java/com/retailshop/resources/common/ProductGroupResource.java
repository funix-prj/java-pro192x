package com.retailshop.resources.common;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.retailshop.pojos.Product;
import com.retailshop.pojos.ProductCategory;

@RestController
@RequestMapping(value="/home")
public class ProductGroupResource {
	
	@RequestMapping(value="/productGroup", method=RequestMethod.GET)
	public List<ProductCategory> getProductGroups(){
		List<ProductCategory> productGroups = new LinkedList<ProductCategory>();
		List<Product> products = Arrays.asList(
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg"),
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg"),
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg"),
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg"),
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg"),
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg"),
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg")
				);
		ProductCategory group1 = new ProductCategory("Hàng mới", products);
		productGroups.add(group1);
		products = Arrays.asList(
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg"),
				new Product("Giỏ quà tết", "100000", "100000","/retail-shop/resources/images/content/product/product3.jpg")
				);
		ProductCategory group2 = new ProductCategory("Khuyến mãi", products);
		productGroups.add(group2);
		
		return productGroups;
	}
}
