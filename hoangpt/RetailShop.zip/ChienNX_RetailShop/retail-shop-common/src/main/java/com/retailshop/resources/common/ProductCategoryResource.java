package com.retailshop.resources.common;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.pojos.SearchPager;
import com.retailshop.biz.service.IProductCategoryService;
import com.retailshop.biz.service.IWhitelabelService;
import com.retailshop.pojos.Product;
import com.retailshop.pojos.ProductCategory;

@RestController
@RequestMapping(value="/common")
public class ProductCategoryResource {
	Logger logger = LoggerFactory.getLogger(ProductCategoryResource.class);
	@Autowired
	private IWhitelabelService whitelabelService;

	@Autowired
	private IProductCategoryService productCategoryService;
	
	@RequestMapping(value="/product-category", method=RequestMethod.POST)
	public List<ProductCategory> saveProductGroup(@RequestBody List<ProductCategory> cates){
		productCategoryService.saveProductCategories(cates, whitelabelService.getLoginWlCode());
		return cates;
	}
	
	@RequestMapping(value="/product-category/{categoryId}", method=RequestMethod.PUT)
	public ProductCategory updateProductGroup(@RequestBody ProductCategory cate){
		productCategoryService.updateProductCateogry(cate, whitelabelService.getLoginWlCode());
		return cate;
	}
	
	@RequestMapping(value="/product-category", method=RequestMethod.GET, params={"p"})
	public SearchPager<ProductCategory> getCategories(@RequestParam(required=true, value="p") long currentPage){
		SearchPager<ProductCategory> cates = productCategoryService.findRecentUpdatedProductCategories(whitelabelService.getLoginWlCode(), currentPage);
		return cates;
	}
	
	@RequestMapping(value="/product-category/{categoryId}", method=RequestMethod.DELETE)
	public Integer deleteProductCategory(@PathVariable(value="categoryId") long categoryId){
		return productCategoryService.deleteProductCategory(categoryId, whitelabelService.getLoginWlCode());
	}
	
	@RequestMapping(value="/product-category/{categoryId}/products", method=RequestMethod.GET)
	public SearchPager<Product> getProductsBelongToCategory(@PathVariable(value="categoryId") long categoryId, @RequestParam(value="p") long currentPage){
		return productCategoryService.getProductsBelongToCategory(categoryId, whitelabelService.getLoginWlCode(), currentPage);
	}
}
