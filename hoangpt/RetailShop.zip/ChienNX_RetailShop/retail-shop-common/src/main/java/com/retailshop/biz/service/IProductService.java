package com.retailshop.biz.service;

import java.util.List;

import com.myproject.pojos.SearchPager;
import com.retailshop.pojos.Product;

public interface IProductService {

	void saveProducts(List<Product> products, String wlCode);

	SearchPager<Product> findRecentUpdatedProducts(String loginWlCode, long currentPage);

	int deleteProduct(long productId, String wlCode);

	List<Product> findProductsWithName(String keyword, String loginWlCode);
	SearchPager<Product> findProductsWithName(String keyword, String loginWlCode, long currentPage);

	int updateProductImageLink(String imageName, Long productId, String wlCode);

	Product getProduct(long productId, String wlCode);

	int updateProductName(long productId, String loginWlCode, Product p);

	int updateProductQuantity(long productId, String loginWlCode, Product p);

	int updateProductPrice(long productId, String loginWlCode, Product p);

	int updateProductDescription(long productId, String loginWlCode, Product p);

	int addProductQuantity(long productId, String loginWlCode, Product p);

	

}
