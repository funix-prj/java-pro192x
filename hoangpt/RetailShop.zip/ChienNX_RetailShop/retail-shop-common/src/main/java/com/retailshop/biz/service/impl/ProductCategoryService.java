package com.retailshop.biz.service.impl;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.metamodel.SingularAttribute;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.myproject.enums.FlagStateEnum;
import com.myproject.pojos.SearchPager;
import com.retailshop.biz.service.IProductCategoryService;
import com.retailshop.db.entity.ProductCategoryEntity;
import com.retailshop.db.entity.ProductCategoryEntity_;
import com.retailshop.db.entity.ProductEntity;
import com.retailshop.pojos.Product;
import com.retailshop.pojos.ProductCategory;

@Service
@Transactional
public class ProductCategoryService extends BaseService implements IProductCategoryService{
	
	private static final Logger logger = LoggerFactory.getLogger(ProductCategoryService.class);
	
	public void saveProductCategories(List<ProductCategory> cates, String wlCode) {
		logger.info("[start] save product categories");
		cates.parallelStream().forEach(saveProductCategory(wlCode));
	}
	
	private Consumer<ProductCategory> saveProductCategory(String wlCode){
		return c -> {
			ProductCategoryEntity e = new ProductCategoryEntity();
			e.setName(c.getGroupName());
			e.setWlCode(wlCode);
			
			e.setActiveFlg(FlagStateEnum.ON.INT_VAL);
			Timestamp current = new Timestamp(System.currentTimeMillis());
			e.setUpdateDate(current);
			e.setInputDate(current);
			
			getProductCategoryDAO().save(e);
			
			c.setId(e.getId());
		};
	}

	public SearchPager<ProductCategory> findRecentUpdatedProductCategories(String loginWlCode, long currentPage) {
		int pageSize= 5;
		Stream<ProductCategory> cates = getProductCategoryDAO().findRecentUpdatedProductCategories(loginWlCode, currentPage, pageSize).parallel()
				.map(convertToProductCategoryDomain());
		
		long maxResults = getProductCategoryDAO().countRecentUpdatedProductCategories(loginWlCode);
		
		SearchPager<ProductCategory> pager = new SearchPager<ProductCategory>(pageSize, currentPage, maxResults, cates.collect(Collectors.toList()));
		
		return pager;
	}
	
	private Function<ProductCategoryEntity, ProductCategory> convertToProductCategoryDomain(){
		return e -> {
			ProductCategory p = new  ProductCategory();
			p.setId(e.getId());
			p.setGroupName(e.getName());
			return p;
		};
	}

	public int deleteProductCategory(long categoryId, String wlCode) {
		logger.info("delete product category - categoryId: "+categoryId);
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		updates.put(ProductCategoryEntity_.activeFlg, FlagStateEnum.OFF.INT_VAL);
		return getProductCategoryDAO().update(categoryId, updates, wlCode);
	}

	public void updateProductCateogry(ProductCategory cate, String loginWlCode) {
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		if(!StringUtils.isEmpty(cate.getGroupName())){
			updates.put(ProductCategoryEntity_.name, cate.getGroupName());
		}
		getProductCategoryDAO().update(cate.getId(), updates, loginWlCode);
	}
	
	@Override
	public SearchPager<Product> getProductsBelongToCategory(long categoryId, String loginWlCode, long currentPage) {
		int pageSize= 5;
		Stream<Product> products = getProductCategoryDAO().getProductsBelongToCategory(categoryId, loginWlCode, currentPage, pageSize).map(convertToProductDomain());
		
		long maxResults = getProductCategoryDAO().getProductsBelongToCategory(categoryId, loginWlCode).count();
		
		SearchPager<Product> pager = new SearchPager<Product>(pageSize, currentPage, maxResults, products.collect(Collectors.toList()));
		
		return pager;
	}
}
