package com.retailshop.resources.common;

import java.util.List;

import org.junit.runner.Request;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.pojos.SearchPager;
import com.retailshop.biz.service.IProductService;
import com.retailshop.biz.service.IWhitelabelService;
import com.retailshop.pojos.Product;

@RestController
@RequestMapping(value="/common")
public class ProductResource {
	Logger logger = LoggerFactory.getLogger(ProductResource.class);
	
	@Autowired
	private IProductService productService;
	@Autowired
	private IWhitelabelService whitelabelService;
	
	@RequestMapping(value="/product", method=RequestMethod.GET, params={"p"})
	public SearchPager<Product> getProducts(@RequestParam(required=true, value="p") long currentPage){
		SearchPager<Product> products = productService.findRecentUpdatedProducts(whitelabelService.getLoginWlCode(), currentPage);
		return products;
	}
	
	@RequestMapping(value="/product", method=RequestMethod.GET, params={"q"})
	public List<Product> getProducts(@RequestParam(required=true, value="q") String keyword){
		logger.info("search product - keyword: "+keyword);
		List<Product> products = productService.findProductsWithName(keyword, whitelabelService.getLoginWlCode());
		return products;
	}
	
	@RequestMapping(value="/product", method=RequestMethod.GET, params={"q", "p"})
	public SearchPager<Product> getProducts(@RequestParam(required=true, value="q") String keyword, @RequestParam(required=true, value="p") long currentPage){
		logger.info("search product - keyword: "+keyword);
		SearchPager<Product> products = productService.findProductsWithName(keyword, whitelabelService.getLoginWlCode(), currentPage);
		return products;
	}
	
	@RequestMapping(value="/product", method=RequestMethod.POST)
	public List<Product> saveProduct(@RequestBody List<Product> products){
		productService.saveProducts(products, whitelabelService.getLoginWlCode());
		return products;
	}
	
	@RequestMapping(value="/product/{productId}", method=RequestMethod.GET)
	public Product getProduct(@PathVariable(value="productId") long productId){
		return productService.getProduct(productId, whitelabelService.getLoginWlCode());
	}
	
	@RequestMapping(value="/product/{productId}", method=RequestMethod.DELETE)
	public Integer deleteProduct(@PathVariable(value="productId") long productId){
		return productService.deleteProduct(productId, whitelabelService.getLoginWlCode());
	}
	
	
	@RequestMapping(value="/product/{productId}/name", method=RequestMethod.PUT)
	public int updateProductName(@PathVariable long productId, @RequestBody Product p){
		return productService.updateProductName(productId, whitelabelService.getLoginWlCode(), p);
	}
	
	@RequestMapping(value="/product/{productId}/quantity", method=RequestMethod.PUT)
	public int updateProductQuantity(@PathVariable long productId, @RequestBody Product p){
		return productService.updateProductQuantity(productId, whitelabelService.getLoginWlCode(), p);
	}
	
	@RequestMapping(value="/product/{productId}/quantity", method=RequestMethod.POST)
	public int addProductQuantity(@PathVariable long productId, @RequestBody Product p){
		return productService.addProductQuantity(productId, whitelabelService.getLoginWlCode(), p);
	}
	
	@RequestMapping(value="/product/{productId}/price", method=RequestMethod.PUT)
	public int updateProductPrice(@PathVariable long productId, @RequestBody Product p){
		return productService.updateProductPrice(productId, whitelabelService.getLoginWlCode(), p);
	}
	
	@RequestMapping(value="/product/{productId}/description", method=RequestMethod.PUT)
	public int updateProductDescription(@PathVariable long productId, @RequestBody Product p){
		return productService.updateProductDescription(productId, whitelabelService.getLoginWlCode(), p);
	}
}
