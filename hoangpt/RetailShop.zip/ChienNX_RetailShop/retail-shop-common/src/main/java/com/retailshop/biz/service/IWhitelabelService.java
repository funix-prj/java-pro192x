package com.retailshop.biz.service;

public interface IWhitelabelService {
	public String getLoginWlCode();
}
