package com.retailshop.biz.service;

import java.util.List;

import com.myproject.pojos.SearchPager;
import com.retailshop.pojos.Product;
import com.retailshop.pojos.ProductCategory;

public interface IProductCategoryService {

	void saveProductCategories(List<ProductCategory> products, String wlCode);

	SearchPager<ProductCategory> findRecentUpdatedProductCategories(String loginWlCode, long currentPage);

	int deleteProductCategory(long categoryId, String wlCode);

	void updateProductCateogry(ProductCategory cate, String loginWlCode);

	SearchPager<Product> getProductsBelongToCategory(long categoryId, String loginWlCode, long currentPage);


}
