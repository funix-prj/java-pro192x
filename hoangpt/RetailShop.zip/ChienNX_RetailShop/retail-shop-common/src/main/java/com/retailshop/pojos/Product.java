package com.retailshop.pojos;

public class Product {
	private Long productId;
	private String imgUrl;
	private String suppressedPrice;
	private String price;
	private String sellPrice;
	private String buyPrice;
	private String quantity;
	private boolean isNew;
	private boolean isPromotion;
	private boolean isHot;
	private String name;
	private String description;
	
	public Product(){}
	public Product(String name, String price, String suppressedPrice, String imgUrl){
		this.imgUrl = imgUrl;
		this.suppressedPrice = suppressedPrice;
		this.price = price;
		this.name = name;
	}
	
	
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public boolean isHot() {
		return isHot;
	}
	public void setHot(boolean isHot) {
		this.isHot = isHot;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSellPrice() {
		return sellPrice;
	}
	public void setSellPrice(String sellPrice) {
		this.sellPrice = sellPrice;
	}
	public String getBuyPrice() {
		return buyPrice;
	}
	public void setBuyPrice(String buyPrice) {
		this.buyPrice = buyPrice;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public boolean isNew() {
		return isNew;
	}
	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}
	public boolean isPromotion() {
		return isPromotion;
	}
	public void setPromotion(boolean isPromotion) {
		this.isPromotion = isPromotion;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public String getSuppressedPrice() {
		return suppressedPrice;
	}
	public void setSuppressedPrice(String suppressedPrice) {
		this.suppressedPrice = suppressedPrice;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
