package com.retailshop.biz.service.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.metamodel.SingularAttribute;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.myproject.enums.FlagStateEnum;
import com.myproject.pojos.SearchPager;
import com.retailshop.biz.service.IProductService;
import com.retailshop.db.entity.ProductEntity;
import com.retailshop.db.entity.ProductEntity_;
import com.retailshop.pojos.Product;

@Service
@Transactional
public class ProductService extends BaseService implements IProductService{
	
	private static final Logger logger = LoggerFactory.getLogger(ProductService.class);
	
	public void saveProducts(List<Product> products, String wlCode) {
		products.parallelStream().forEach(saveProduct(wlCode));
	}
	
	private Consumer<Product> saveProduct(String wlCode){
		return p -> {
			ProductEntity e = new ProductEntity();
			e.setName(p.getName());
			e.setQuantity(Integer.valueOf(p.getQuantity()));
			e.setBuyPrice(new BigDecimal(p.getBuyPrice()));
			e.setSellPrice(new BigDecimal(p.getSellPrice()));
			e.setHotFlg(FlagStateEnum.valueOfBool(p.isHot()).INT_VAL);
			e.setNewFlg(FlagStateEnum.valueOfBool(p.isNew()).INT_VAL);
			e.setPromoteFlg(FlagStateEnum.valueOfBool(p.isPromotion()).INT_VAL);
			e.setDescription(p.getDescription());
			e.setWlCode(wlCode);
			
			e.setActiveFlg(FlagStateEnum.ON.INT_VAL);
			Timestamp current = new Timestamp(System.currentTimeMillis());
			e.setUpdateDate(current);
			e.setInputDate(current);
			
			getProductDAO().save(e);
			
			p.setProductId(e.getId());
		};
	}

	public SearchPager<Product> findRecentUpdatedProducts(String loginWlCode, long currentPage) {
		int pageSize= 5;
		Stream<Product> products = getProductDAO().findRecentUpdatedProducts(loginWlCode, currentPage, pageSize).parallel()
				.map(convertToProductDomain());
		
		long maxResults = getProductDAO().findProductsByWhitelabel(loginWlCode).count();
		
		SearchPager<Product> pager = new SearchPager<Product>(pageSize, currentPage, maxResults, products.collect(Collectors.toList()));
		
		return pager;
	}
	
	@Override
	public List<Product> findProductsWithName(String keyword, String loginWlCode) {
		return getProductDAO().findProductsWithName(keyword, loginWlCode).parallel()
				.map(convertToProductDomain()).collect(Collectors.toList());
	}
	
	@Override
	public SearchPager<Product> findProductsWithName(String keyword, String loginWlCode, long currentPage) {
		int pageSize= 5;
		Stream<Product> products = getProductDAO().findProductsWithName(keyword, loginWlCode, currentPage, pageSize).parallel()
				.map(convertToProductDomain());
		
		long maxResults = getProductDAO().findProductsWithName(keyword, loginWlCode).count();
		
		SearchPager<Product> pager = new SearchPager<Product>(pageSize, currentPage, maxResults, products.collect(Collectors.toList()));
		
		return pager;
	}
	
	public int deleteProduct(long productId, String wlCode) {
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		updates.put(ProductEntity_.activeFlg, FlagStateEnum.OFF.INT_VAL);
		return getProductDAO().update(productId, updates, wlCode);
	}

	public int updateProductImageLink(String imageName, Long productId, String wlCode) {
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		if(!StringUtils.isEmpty(imageName)){
			updates.put(ProductEntity_.imageName, imageName);
		}
		return getProductDAO().update(productId, updates, wlCode);
	}

	@Override
	public Product getProduct(long productId, String wlCode) {
		ProductEntity e = getProductDAO().findById(productId);
		if(!wlCode.equals(e.getWlCode())) return null;
		if(!FlagStateEnum.valueOfInt(e.getActiveFlg()).BOOLEAN_VAL) return null;
		return convertToProductDomain().apply(e);
	}


	@Override
	public int updateProductName(long productId, String loginWlCode, Product p) {
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		if(!StringUtils.isEmpty(p.getName())){
			updates.put(ProductEntity_.name, p.getName());
		}
		return getProductDAO().update(productId, updates, loginWlCode);
	}

	@Override
	public int updateProductQuantity(long productId, String loginWlCode, Product p) {
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		if(!StringUtils.isEmpty(p.getQuantity())){
			updates.put(ProductEntity_.quantity, p.getQuantity());
		}
		return getProductDAO().update(productId, updates, loginWlCode);
	}

	@Override
	public int updateProductPrice(long productId, String loginWlCode, Product p) {
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		if(!StringUtils.isEmpty(p.getSellPrice())){
			updates.put(ProductEntity_.sellPrice, p.getSellPrice());
		}
		if(!StringUtils.isEmpty(p.getBuyPrice())){
			updates.put(ProductEntity_.buyPrice, p.getBuyPrice());
		}
		return getProductDAO().update(productId, updates, loginWlCode);
	}

	@Override
	public int updateProductDescription(long productId, String loginWlCode, Product p) {
		Map<SingularAttribute, Object> updates = new HashMap<SingularAttribute, Object>();
		updates.put(ProductEntity_.hotFlg, FlagStateEnum.valueOfBool(p.isHot()).INT_VAL);
		updates.put(ProductEntity_.newFlg, FlagStateEnum.valueOfBool(p.isNew()).INT_VAL);
		updates.put(ProductEntity_.promoteFlg, FlagStateEnum.valueOfBool(p.isPromotion()).INT_VAL);
		
		if(p.getDescription() != null){
			updates.put(ProductEntity_.description, p.getDescription());
		}
		
		return getProductDAO().update(productId, updates, loginWlCode);
	}
	
	@Override
	public int addProductQuantity(long productId, String wlCode, Product p) {
		return getProductDAO().addProductQuantity(productId, Integer.parseInt(p.getQuantity()), wlCode);
	}
}
