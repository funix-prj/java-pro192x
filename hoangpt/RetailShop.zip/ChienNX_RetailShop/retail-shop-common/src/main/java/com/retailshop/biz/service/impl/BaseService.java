package com.retailshop.biz.service.impl;

import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.myproject.enums.FlagStateEnum;
import com.retailshop.db.dao.IProductCategoryDAO;
import com.retailshop.db.dao.IProductDAO;
import com.retailshop.db.entity.ProductCategoryEntity;
import com.retailshop.db.entity.ProductEntity;
import com.retailshop.pojos.Product;

@Service
@Transactional
public class BaseService {
	@Autowired
	private IProductDAO<ProductEntity> productDAO;
	
	@Autowired 
	private IProductCategoryDAO<ProductCategoryEntity> productCategoryDAO;
	
	Function<ProductEntity, Product> convertToProductDomain(){
		return e -> {
			Product p = new  Product();
			p.setProductId(e.getId());
			p.setName(e.getName());
			p.setDescription(e.getDescription());
			p.setHot(FlagStateEnum.valueOfInt(e.getHotFlg()).BOOLEAN_VAL);
			p.setNew(FlagStateEnum.valueOfInt(e.getNewFlg()).BOOLEAN_VAL);
			p.setPromotion(FlagStateEnum.valueOfInt(e.getPromoteFlg()).BOOLEAN_VAL);
			p.setImgUrl(e.getImageName());
			p.setBuyPrice(e.getBuyPrice().toPlainString());
			p.setSellPrice(e.getSellPrice().toPlainString());
			p.setQuantity(e.getQuantity().toString());
			return p;
		};
	}
	
	public IProductCategoryDAO<ProductCategoryEntity> getProductCategoryDAO() {
		return productCategoryDAO;
	}

	public void setProductCategoryDAO(IProductCategoryDAO<ProductCategoryEntity> productCategoryDAO) {
		this.productCategoryDAO = productCategoryDAO;
	}

	public IProductDAO<ProductEntity> getProductDAO() {
		return productDAO;
	}

	public void setProductDAO(IProductDAO<ProductEntity> productDAO) {
		this.productDAO = productDAO;
	}
	
}
