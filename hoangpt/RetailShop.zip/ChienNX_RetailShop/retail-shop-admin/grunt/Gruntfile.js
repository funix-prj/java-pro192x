module.exports = function (grunt) {

    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        
       // concat: {
       //     'dest/a.js': ['../src/main/webapp/WEB-INF/js/**/*.js']
       // }, 
        
        uglify: {
            options: {
                report: 'min',
                compress: true,
                mangle: true,
                sourceMap:true,
                sourceMapIncludeSources: true,
                sourceMapName: '../src/main/webapp/WEB-INF/js/dist/r.map'
            },
            my_target: {
	    /*        files: [{
	            	expand: true,
	            	cwd: '../src/main/webapp/WEB-INF/js',
	            	src: [
						'lib/jquery/1.11.2/jquery-1.11.2.min.js',
						'lib/jquery-typing/0.2.0/jquery.typing-0.2.0.min.js',
						'lib/bootstrap/3.3.4/bootstrap.min.js',
						'lib/angularjs/1.3.16/angular.min.js',
						'lib/angularjs/1.3.16/angular-resource.min.js',
						'lib/angularjs/1.3.16/angular-sanitize.min.js',
						'lib/angularjs/1.3.16/angular-animate.min.js',
						'lib/angularjs/angular-ui-router.min.js',
						'lib/angularjs/angular-translate.min.js',
						'lib/angular-ui/0.13.0/ui-bootstrap.min.js',
						'lib/angular-ui/0.13.0/ui-bootstrap-tpls.min.js',
						'lib/angular-ui/0.11.2/ui-bootstrap-tpls-0.11.2.min.js',
						'lib/angular-dialog/5.2.8/dialogs.min.js',
						'lib/angular-fileupload/5.0.7/ng-file-upload.min.js',
						'app.js',
						'controllers.js',
						'router.js',
						'lang/en_us.js',
						'lang/vi_vn.js'
	            	 ]
	            }],*/
	            files: {
	            	'../src/main/webapp/WEB-INF/js/dist/r.js': [
						'../src/main/webapp/WEB-INF/js/lib/jquery/1.11.2/jquery-1.11.2.min.js',
						'../src/main/webapp/WEB-INF/js/lib/jquery-typing/0.2.0/jquery.typing-0.2.0.min.js',
						'../src/main/webapp/WEB-INF/js/lib/bootstrap/3.3.4/bootstrap.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular-resource.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular-sanitize.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular-animate.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angularjs/angular-ui-router.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angularjs/angular-translate.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angular-ui/0.13.0/ui-bootstrap.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angular-ui/0.13.0/ui-bootstrap-tpls.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angular-ui/0.11.2/ui-bootstrap-tpls-0.11.2.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angular-dialog/5.2.8/dialogs.min.js',
						'../src/main/webapp/WEB-INF/js/lib/angular-fileupload/5.0.7/ng-file-upload.min.js',                   
						'../src/main/webapp/WEB-INF/js/app.js',
						'../src/main/webapp/WEB-INF/js/controllers.js',
						'../src/main/webapp/WEB-INF/js/router.js',
						'../src/main/webapp/WEB-INF/js/lang/en_us.js',
						'../src/main/webapp/WEB-INF/js/lang/vi_vn.js'
	            	]
	            }
            },
            /*dist: {
                src: [],
                dest: 'dist/main.min.js'
            }*/
        },
        concat: {
            'dist/a.js': [
					'../src/main/webapp/WEB-INF/js/lib/jquery/1.11.2/jquery-1.11.2.min.js',
					'../src/main/webapp/WEB-INF/js/lib/jquery-typing/0.2.0/jquery.typing-0.2.0.min.js',
					'../src/main/webapp/WEB-INF/js/lib/bootstrap/3.3.4/bootstrap.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular-resource.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular-sanitize.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angularjs/1.3.16/angular-animate.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angularjs/angular-ui-router.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angularjs/angular-translate.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angular-ui/0.13.0/ui-bootstrap.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angular-ui/0.13.0/ui-bootstrap-tpls.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angular-ui/0.11.2/ui-bootstrap-tpls-0.11.2.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angular-dialog/5.2.8/dialogs.min.js',
					'../src/main/webapp/WEB-INF/js/lib/angular-fileupload/5.0.7/ng-file-upload.min.js',
					'dist/custom.min.js'
            ]
       }
        /*clean: ["dist"],

        copy: {
            main: {
                expand: true,
                cwd: '',
                src:['src/main/webapp/WEB-INF/js/**'],
                dest: 'dist/'
            }
        },*/
/*
        useminPrepare: {
            html: 'app/index.html'
        },

        usemin: {
            html: ['dist/app/index.html']
        },*/

        /*uglify: {
            options: {
                report: 'min',
                mangle: true
            }
        }*/
    });

    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-uglify');
   // grunt.loadNpmTasks('grunt-usemin');

/*    grunt.registerTask('adjustBuiltLinks', 'Performing Final Cleanups', function() {

        var indexDist='dist/app/index.html';

        grunt.log.writeln('Performing Final Cleanups');

        var indexContent=grunt.file.read(indexDist);

        indexContent=indexContent.replace('<link rel="stylesheet" href="app/built/app.min.css"/>','<link rel="stylesheet" href="built/app.min.css"/>');

        indexContent=indexContent.replace('<script src="app/built/app.min.js"></script>','<script src="built/app.min.js"></script>');

        grunt.file.write(indexDist, indexContent);

    });
*/

    // Tell Grunt what to do when we type "grunt" into the terminal
    grunt.registerTask('default', [
       //'clean', 'copy', 'useminPrepare', 'concat', 'uglify', 'cssmin' //, 'usemin' //,'adjustBuiltLinks'
       'uglify'
    ]);

};