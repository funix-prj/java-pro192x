package com.retailshop.biz.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.retailshop.biz.service.IWhitelabelService;

@Service
@Transactional
public class WhitelabelService extends BaseService implements IWhitelabelService{

	@Override
	public String getLoginWlCode() {
		return "BN"; //TODO: hard code - need to implement after having spring security authentication
	}

}
