'use strict'

angular.module('retailShop',['ui.router', 'ui.bootstrap', 'dialogs.main', 'pascalprecht.translate', 
                             'ngResource', 'ngAnimate', 'ngFileUpload']);

angular.module('retailShop').run(['$state','$rootScope','$translate',function($state,$rootScope,$translate){
	$translate.use('vi_vn');
	$state.go('admin.product');
}]);