'use strict'

angular.module('retailShop').config(['$translateProvider',function($translateProvider){
    $translateProvider.translations('en_us', {
        'page.title': 'The Retail Shop',
        'page.header': 'Shop Management',
        'dashboard.product' : 'Product',
        'page.product.title': 'Product Management',
        'page.product.list.title': 'Product List',
        'page.product.list.table.header.01':'Product',
        'page.product.list.table.header.02':'Quantity',
        'page.product.list.table.header.03':'Buy Price',
        'page.product.list.table.header.04':'Sell Price',
        'page.product.list.form.input.product.name': 'Product Name',
        'page.product.list.form.input.product.quantity': 'Quantity',
        'page.product.list.form.input.product.buy.price': 'Buy Price',
        'page.product.list.form.input.product.sell.price': 'Sell Price',
        'global.currency.code':'VND',
        
        'dashboard.product.category': 'Product Category',
        'page.product.category.title': 'Product Cateogry Management',
        'page.product.category.list.title': 'Product Category List',
        'page.product.category.list.table.header.01': 'Category Name',
        'page.product.category.list.table.header.02': 'Number of Products'
    });
}]);