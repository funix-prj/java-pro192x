'use strict'

angular.module('retailShop').config(['$translateProvider',function($translateProvider){
    $translateProvider.translations('vi_vn', {
        'page.title': 'Cửa Hàng Tạp Hóa',
        'page.header': 'Quản lý cửa hàng',
        'dashboard.product': 'Mặt hàng',
        'page.product.title': 'Quản lý mặt hàng',
        'page.product.list.title': 'Danh sách mặt hàng',
        'page.product.list.table.header.01':'Mặt hàng',
        'page.product.list.table.header.02':'Số lượng trong kho',
        'page.product.list.table.header.03':'Giá mua',
        'page.product.list.table.header.04':'Giá bán',
        'page.product.list.form.input.product.name': 'Tên sản phẩm',
        'page.product.list.form.input.product.quantity': 'Số lượng nhập',
        'page.product.list.form.input.product.buy.price': 'Giá mua',
        'page.product.list.form.input.product.sell.price': 'Giá bán',
        'global.currency.code':'VND',
        
        'dashboard.product.category': 'Nhóm mặt hàng',
        'page.product.category.title': 'Quản lý nhóm mặt hàng',
        'page.product.category.list.title': 'Danh sách nhóm mặt hàng',
        'page.product.category.list.table.header.01': 'Tên nhóm sản phẩm',
        'page.product.category.list.table.header.02': 'Chi tiết'
    });
}]);