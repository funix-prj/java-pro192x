'use strict'

angular.module('retailShop')
.controller('ProductDetailEditableCtrl', ['$scope', '$rootScope', '$resource', 'ConfirmDialog', 'Upload', '$q', 'ConstantsService', 
                                 function($scope, $rootScope, $resource, $confirm, Upload, $q, $constants){
	
	$rootScope.$on($constants.Events.REFRESH_PRODUCT_INPUT_PANEL, function(evt, data){
		$scope.cancelProductInput();
	});
	
	$scope.cancelProductInput = function(){
		$scope.inputProduct = {};
		$scope.picFile = null;
	};
	
	var Product = $resource('common/product', null, {'save': {method: 'POST', isArray:true}});
		
	$scope.saveProduct = function(){
		var i = $scope.inputProduct;
		if(i){
			if(i.existingFlg){
				var ProductQuantity = $resource('common/product/:productId/quantity', {'productId':'@id'}, {'update': {method: 'PUT'}});
				var pQuantity = new ProductQuantity({id:i.productId});
				pQuantity.quantity = i.quantity;
				pQuantity.$save(function(){
					$scope.loadProducts(0);
				});
			}else{
				var p = {
					name: i.name,
					quantity: i.quantity,
					buyPrice: i.buyPrice,
					sellPrice: i.sellPrice,
					'new': (i.newFlg ? true : false),
					promotion: (i.promotionFlg ? true : false),
					hot: (i.hotFlg ? true : false),
					description: i.description
				};
				
				var x = [];
				x.push(p);
				Product.save(x, function(savedProducts){
					i.saved = (savedProducts && savedProducts.length == 1);
					if(i.saved){
						$scope.uploadPic($scope.picFile, savedProducts[0].productId);
						$scope.picFile[0].isComplete().then(function(){
							$scope.loadProducts(0);
						});
					}
				}, function(){
					console.log('error');
				});
			}
		}
	};
	
	
	$scope.uploadPic = function (files, pid) {
        if (files != null) {
        	uploadUsingUpload(files[0], pid)
        }
    };
    
    function uploadUsingUpload(file, pid) {
    	file.$defer = $q.defer();
    	
        file.upload = Upload.upload({
        	url: 'productimage/upload',
            method: 'POST',
            /*headers: {
                'my-header': 'my-header-value'
            },*/
            fields: {'pid': pid},
            file: file/*,
            fileFormDataName: 'myFile'*/
        });

        file.isComplete = function(){
        	return file.$defer.promise;
        };
        
        file.upload.then(function (response) {
        	if(response.data == true){
        		file.complete = true;
        		file.$defer.resolve();
        	}
        }, function (response) {
            /*if (response.status > 0)
                $scope.errorMsg = response.status + ': ' + response.data;*/
        });

        file.upload.progress(function (evt) {
            // Math.min is to fix IE which reports 200% sometimes
            file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
        });

        file.upload.xhr(function (xhr) {
            // xhr.upload.addEventListener('abort', function(){console.log('abort complete')}, false);
        });
    }
    
    $scope.searchExistingProduct = function(val) {
    	if(val && val.trim() != ''){
			return Product.query({q:val.trim()}).$promise.then(function(results){
				return results;
			});
		}
    };
    
    $scope.selectExistingProduct = function(p, $model, $label){
    	p.quantity = Number(p.quantity);
    	p.buyPrice = Number(p.buyPrice);
    	p.sellPrice = Number(p.sellPrice);
    	p.hotFlg = p.hot;
    	p.newFlg = p['new'];
    	p.promotionFlg = p.promotion;
    	p.existingFlg = true;
    	
    	$scope.inputProduct = p; 
    };
}]);