'use strict'
angular.module('retailShop')
.service('ConfirmDialog', ['$modal', function($modal){
	var self = this;
	self.open = function(msg, yes, no){
		var modalInstance = $modal.open({
			animation: true,
			templateUrl: 'resources/templates/common/popup-confirm.html',
			controller: 'ModalConfirmCtrl',
			size: 'sm',
			resolve: {
				model: function(){
					return {
						content: msg,
						confirmFunc: yes,
						cancelFunc: no
					};
				}
		      }
	    });
		
		self.result = modalInstance.result;
		
		self.close = function(){
			modalInstance.close('ok');
		};
		
		self.dismiss = function(){
			modalInstance.dismiss('cancel');
		};
	}
}]);