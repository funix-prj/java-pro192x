'use strict'

angular.module('retailShop').config(['$stateProvider',function($stateProvider){
	$stateProvider
		.state('admin',{
			url: '',
			views:{
				'view-main':{
					templateUrl: 'resources/templates/main.html'
				},
				'view-content@admin':{
					templateUrl: 'resources/templates/products-list/product-panel.html',
					controller: 'ProductPanelCtrl'
				},
				'view-product-detail@admin': {
					templateUrl: 'resources/templates/products-list/product-detail-editable.html',
					controller: 'ProductDetailEditableCtrl'
				}
			}
		})
		.state('admin.product',{
			url: '/products',
			views:{}
		})
		.state('admin.product.view',{
			url: '/view/:pid',
			views:{
				'view-product-detail@admin': {
					templateUrl: 'resources/templates/products-list/product-detail-view.html',
					controller: 'ProductDetailViewCtrl'
				}
			}
		})
		.state('admin.category',{
			url: '/product-categories',
			views:{
				'view-content@admin':{
					templateUrl: 'resources/templates/product-categories/categories.html',
					controller: 'ProductCategoryCtrl'
				}
			}
		});
}]);