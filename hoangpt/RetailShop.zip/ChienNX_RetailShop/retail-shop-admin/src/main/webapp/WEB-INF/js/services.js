'use strict'
angular.module('retailShop')
.service('ConstantsService', function(){
	var self = this;
	self.Events = {
		MENU_ACTIVE : 'events.menu.active',
		REFRESH_PRODUCT_INPUT_PANEL: 'events.product.refresh.input.panel'
	};
});