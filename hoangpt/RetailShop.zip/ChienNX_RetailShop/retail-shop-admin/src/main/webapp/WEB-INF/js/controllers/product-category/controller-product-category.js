'use strict'

angular.module('retailShop')
.controller('ProductCategoryCtrl', ['$scope', '$resource', 'ConfirmDialog', 'Upload', '$q', 'ConstantsService', '$modal',
                                 function($scope, $resource, $confirm, Upload, $q, $constants, $modal){
	$scope.$emit($constants.Events.MENU_ACTIVE, 'dashboard.product.category');
	
	$scope.openAddGroupPopup = function(){
		var modalInstance = $modal.open({
			animation: true,
			templateUrl: 'resources/templates/product-categories/add-category-popup.html',
			controller: 'ModalAddProductGroupCtrl',
			size: 'sm'
	    });

	    modalInstance.result.then(function (msg) {
	    	if(msg==='ok') $scope.loadCategories(0); 
	    }, function () {});
	};
	
	var Category = $resource('common/product-category', null, {'save': {method: 'POST', isArray:true}});
	
	$scope.loadCategories = function(pageIndex){
		var pager = Category.get({p:pageIndex},function(){
			showCategories(pager);
		});
	};
	
	$scope.loadCategories(0);
	
	function showCategories (pager){
		$scope.lastestCategories = pager.currentResults;
		$scope.totalCategories = pager.maxResults;
		$scope.pagers = [];
		
		for(var i = 0; i< pager.totalPages; i++){
			$scope.pagers.push({active:(i == pager.currentPage)});
		}
	};
	
	$scope.deleteCategory = function(cid, cName){
		$confirm.open('Bạn có muốn xóa nhóm mặt hàng <b>'+cName+'</b> không?', 
			function(){
				var SingleCategory = $resource('common/product-category/:cateId', {'cateId':'@id'});
				var c = new SingleCategory({id:cid});
				c.$delete(function(){
					$scope.loadCategories(0);
					$confirm.close();
				});
			});
	};
	
	$scope.changeGroupName = function(c){
		var SingleCategory = $resource('common/product-category/:cateId', {'cateId':'@id'}, {'update': {method: 'PUT'}});
		var cate = new SingleCategory({id:c.id});
		cate.groupName = c.newGroupName;
		cate.$update(function(){
			c.groupName = c.newGroupName;
			c.editFlg = false;
		});
	};
	
	$scope.showProductBelongToCategory = function(c){
		console.log(c);
		var CategoryProduct = $resource('common/product-category/:categoryId/products', {'categoryId':'@id'}, {'save': {method: 'POST', isArray:true}});
		
		var pager = CategoryProduct.get({categoryId: c.id, p:0}, function(){
			console.log(pager);
		});
	};
	/*------------------------------------------------------------------------------------------*/
	
	var Product = $resource('common/product', null, {'save': {method: 'POST', isArray:true}});
	
	$('#product-search-box').typing({
		stop: function(event, $element){
			if($scope.pKeyword && $scope.pKeyword.trim() != ''){
				var pager = Product.get({q:$scope.pKeyword.trim(), p:0},function(){
					$scope.showProducts(pager);
				});
			}
		},
		delay: 1000
	});
	
	
    
    $scope.searchExistingProduct = function(val) {
    	if(val && val.trim() != ''){
			return Product.get({q:val.trim(), p:0}).$promise.then(function(pager){
				return pager.currentResults;
			});
		}
    };
}])
.controller('ModalAddProductGroupCtrl', ['$scope', '$modalInstance', '$resource', function($scope, $modalInstance, $resource){
	$scope.addProductGroup = function(){
		var Category = $resource('common/product-category', null, {'save': {method: 'POST', isArray:true}});
		var c = [];
		c.push({groupName: $scope.cName});
		Category.save(c, function(saveCates){
			saveCates && saveCates.length == 1 && $modalInstance.close('ok');
		}, function(){
			console.log('error');
		});
	};
	
	$scope.cancel = function(){
		$modalInstance.dismiss('cancel');
	};
}]);