'use strict'

angular.module('retailShop')
.controller('LeftMenuCtrl', ['$scope', '$rootScope', 'ConstantsService', function($scope, $rootScope, $constants){
	$scope.menuItems = [
	    {
	    	name: 'dashboard.product',
	    	link: '#/products',
	    	iconClass: 'fa-dashboard',
	    	active: false,
	    	children: []
	    }, {
	    	name: 'dashboard.product.category',
	    	link: '#/product-categories',
	    	iconClass: 'fa-dashboard',
	    	active: false,
	    	children: []
	    },{
	    	name: 'Menu2',
	    	link: '',
	    	iconClass: 'fa-dashboard',
	    	isCollapsed: true,
	    	active: false,
	    	children: [
	    	    {
	    	    	name: 'Menu2.1',
	    	    	link: '',
	    	    	iconClass: 'fa-dashboard',
	    	    	active: false,
	    	    	children: []
	    	    },{
	    	    	name: 'Menu 2.2',
	    	    	link: '',
	    	    	iconClass: 'fa-dashboard',
	    	    	active: false,
	    	    	children: []
	    	    }       
	    	]
	    },{
	    	name: 'Menu3',
	    	link: '',
	    	iconClass: 'fa-dashboard',
	    	active:false,
	    	children: []
	    }
	];
	
	$rootScope.$on($constants.Events.MENU_ACTIVE, function (evt, activeItem){
		changeActiveMenuItem($scope.menuItems, activeItem);
	});
	
	function changeActiveMenuItem(menuItems, activeItem){
		menuItems.forEach(function(item){
			item.active = (item.name === activeItem);
			item.children.length != 0 && changeActiveMenuItem(item.children, activeItem);
		});
	}
}]);