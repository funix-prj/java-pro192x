package com.retailshop.db.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.Serializable;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import com.retailshop.db.entity.ProductCategoryEntity;

@RunWith(MockitoJUnitRunner.class)
public class ProductCategoryDAOTest {
	ProductCategoryDAO productCategoryDAO;
	@Mock
	EntityManager em;
	
	@Before
	public void init(){
		productCategoryDAO = new ProductCategoryDAO();
		Whitebox.setInternalState(productCategoryDAO, "em", em);
//		Field emField = ReflectionUtils.findField(ProductCategoryDAO.class, "em", EntityManager.class);
//		ReflectionUtils.makeAccessible(emField);
//		ReflectionUtils.setField(emField, productCategoryDAO, em);
		
	}
	
	@Test
	public void test_find_recent_updated_categories(){
		ProductCategoryEntity e = new ProductCategoryEntity();
		e.setId(2L);
		e.setName("mock entity");
		when(em.find(any(Class.class), any(Serializable.class))).thenReturn(e);
		ProductCategoryEntity result = productCategoryDAO.findById(e.getId());
		assertNotNull(result);
		assertEquals(e.getId(), result.getId());
	}
}
