package com.retailshop.db.dao.impl;

import java.sql.Timestamp;
import java.util.Map;
import java.util.stream.Stream;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.SingularAttribute;

import org.springframework.stereotype.Repository;

import com.myproject.enums.FlagStateEnum;
import com.retailshop.db.dao.IProductCategoryDAO;
import com.retailshop.db.entity.ProductCategoryEntity;
import com.retailshop.db.entity.ProductCategoryEntity_;
import com.retailshop.db.entity.ProductEntity;

@Repository
public class ProductCategoryDAO extends BaseDAO<ProductCategoryEntity> implements IProductCategoryDAO<ProductCategoryEntity>{
	public ProductCategoryDAO(){
		super();
		setClass(ProductCategoryEntity.class);
	}

	@Override
	public Stream<ProductCategoryEntity> findRecentUpdatedProductCategories(String wlCode, long currentPage, int pageSize) {
		Query q = getRecentUpdatedQuery(wlCode, false);
		q.setFirstResult((int) (currentPage * pageSize));
		q.setMaxResults((int) pageSize);
		return q.getResultList().stream();
	}

	@Override
	public long countRecentUpdatedProductCategories(String wlCode) {
		return (long) getRecentUpdatedQuery(wlCode, true).getSingleResult();
	}
	
	private Query getRecentUpdatedQuery(String wlCode, boolean isCount){
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		Class c = isCount ? Long.class : ProductCategoryEntity.class;
		
		CriteriaQuery query = cb.createQuery(c);

		Root<ProductCategoryEntity> root = query.from(ProductCategoryEntity.class);
		Predicate isActive = cb.equal(root.get(ProductCategoryEntity_.activeFlg), FlagStateEnum.ON.INT_VAL);
		Predicate belongWlCode = cb.equal(root.get(ProductCategoryEntity_.wlCode), wlCode);
		query.where(cb.and(belongWlCode, isActive));

		if(!isCount){
			query.orderBy(cb.desc(root.get(ProductCategoryEntity_.updateDate)));
			return getEntityManager().createQuery(query.select(root));
		}else{
			return getEntityManager().createQuery(query.select(cb.count(root)));
		}
	}

	/*@Override
	public int delete(long categoryId) {
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		CriteriaUpdate<ProductCategoryEntity> cmd = cb.createCriteriaUpdate(ProductCategoryEntity.class);
		Root<ProductCategoryEntity> root = cmd.from(ProductCategoryEntity.class);
		cmd.set(root.get(ProductCategoryEntity_.activeFlg), FlagStateEnum.OFF.getNumberVal());
		cmd.set(root.get(ProductCategoryEntity_.updateDate), new Timestamp(System.currentTimeMillis()));
		cmd.where(cb.equal(root.get(ProductCategoryEntity_.id), categoryId));
		
		return getEntityManager().createQuery(cmd).executeUpdate();
	}*/

	@Override
	public int update(long categoryId, Map<SingularAttribute, Object> updates, String wlCode) {
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		CriteriaUpdate<ProductCategoryEntity> cmd = cb.createCriteriaUpdate(ProductCategoryEntity.class);
		Root<ProductCategoryEntity> root = cmd.from(ProductCategoryEntity.class);
		
		if(updates.containsKey(ProductCategoryEntity_.name)){
			cmd.set(root.get(ProductCategoryEntity_.name), String.valueOf(updates.get(ProductCategoryEntity_.name)));
		}
		
		if(updates.containsKey(ProductCategoryEntity_.activeFlg)){
			cmd.set(root.get(ProductCategoryEntity_.activeFlg), Integer.valueOf(updates.get(ProductCategoryEntity_.activeFlg).toString()));
		}
		
		cmd.set(root.get(ProductCategoryEntity_.updateDate), new Timestamp(System.currentTimeMillis()));
		cmd.where(cb.and(
				cb.equal(root.get(ProductCategoryEntity_.id), categoryId),
				cb.equal(root.get(ProductCategoryEntity_.activeFlg), FlagStateEnum.ON.INT_VAL),
				cb.equal(root.get(ProductCategoryEntity_.wlCode), wlCode)
				));
		
		return getEntityManager().createQuery(cmd).executeUpdate();
	}	
	
	@Override
	public Stream<ProductEntity> getProductsBelongToCategory(long categoryId, String wlCode, long currentPage, int pageSize) {
		return getProductsBelongToCategory(categoryId, wlCode).skip(currentPage * pageSize).limit(pageSize); 
	}
	
	@Override
	public Stream<ProductEntity> getProductsBelongToCategory(long categoryId, String wlCode) {
		int active = FlagStateEnum.ON.INT_VAL;
		return getJinqStream().joinList(c -> c.getProducts())
		.where(pair -> pair.getOne().getId() == categoryId)
		.where(pair -> pair.getOne().getActiveFlg() == active)
		.where(pair -> pair.getOne().getWlCode().equals(wlCode))
		.where(pair -> pair.getTwo().getActiveFlg() == active)
		.where(pair -> pair.getTwo().getWlCode().equals(wlCode))
		.select(pair -> pair.getTwo());
	}
	
	/*@Override
	public List<ProductEntity> getProductsBelongToCategory(long categoryId, String wlCode, long currentPage, int pageSize) {
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		
		CriteriaQuery<ProductEntity> query = cb.createQuery(ProductEntity.class);

		Root<ProductEntity> root = query.from(ProductEntity.class);
		Join<ProductEntity, ProductCategoryEntity> join = root.join(ProductEntity_.cates);
		
		Predicate isCate = cb.equal(join.get(ProductCategoryEntity_.id), categoryId);
		Predicate isCateActive = cb.equal(join.get(ProductCategoryEntity_.activeFlg), FlagStateEnum.ON.INT_VAL);
		Predicate belongCWlCode = cb.equal(join.get(ProductCategoryEntity_.wlCode), wlCode);
		
		Predicate isProductActive = cb.equal(root.get(ProductEntity_.activeFlg), FlagStateEnum.ON.INT_VAL);
		Predicate belongPWlCode = cb.equal(root.get(ProductEntity_.wlCode), wlCode);
		
		query.where(cb.and(isCate,isCateActive, belongCWlCode, isProductActive, belongPWlCode));
		
		return getEntityManager().createQuery(query.select(root)).getResultList();
	}*/
}
