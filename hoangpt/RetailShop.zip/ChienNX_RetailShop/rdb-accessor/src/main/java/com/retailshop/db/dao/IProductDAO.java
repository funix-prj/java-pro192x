package com.retailshop.db.dao;

import java.util.Map;
import java.util.stream.Stream;

import javax.persistence.metamodel.SingularAttribute;

public interface IProductDAO<T> extends IBaseDAO<T> {
	
	Stream<T> findProductsByWhitelabel(String wlCode);
	Stream<T> findRecentUpdatedProducts(String wlCode, long currentPage, long pageSize);
	Stream<T> findProductsWithName(String keyword, String wlCode);
	Stream<T> findProductsWithName(String keyword, String wlCode, long currentPage, int pageSize);
	
	int update(long productId, Map<SingularAttribute, Object> updates, String loginWlCode);
	int addProductQuantity(long productId, int parseInt, String wlCode);
	

	

}
