package com.retailshop.db.dao;

import java.io.Serializable;

public interface IBaseDAO<T> {
	public T findById(Serializable id);
	public T save(T t);
}
