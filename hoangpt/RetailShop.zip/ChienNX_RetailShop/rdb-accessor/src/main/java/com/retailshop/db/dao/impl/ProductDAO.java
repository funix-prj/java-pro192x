package com.retailshop.db.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Map;
import java.util.stream.Stream;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.SingularAttribute;

import org.jinq.jpa.JPQL;
import org.jinq.orm.stream.JinqStream;
import org.springframework.stereotype.Repository;

import com.myproject.enums.FlagStateEnum;
import com.retailshop.db.dao.IProductDAO;
import com.retailshop.db.entity.ProductEntity;
import com.retailshop.db.entity.ProductEntity_;

@Repository
public class ProductDAO extends BaseDAO<ProductEntity> implements IProductDAO<ProductEntity>{
	public ProductDAO(){
		super();
		setClass(ProductEntity.class);
	}
	
	@Override
	public Stream<ProductEntity> findProductsWithName(String keyword, String wlCode) {
		return findByWhitelabel(wlCode).where(p -> JPQL.like(p.getName(), "%"+keyword+"%"));
	}
	
	@Override
	public Stream<ProductEntity> findProductsWithName(String keyword, String wlCode, long currentPage, int pageSize) {
		return findProductsWithName(keyword, wlCode).skip(currentPage*pageSize).limit(pageSize);
	}

	@Override
	public Stream<ProductEntity> findProductsByWhitelabel(String wlCode) {
		return findByWhitelabel(wlCode);
	}
	
	@Override
	public Stream<ProductEntity> findRecentUpdatedProducts(String wlCode, long currentPage, long pageSize) {
		return findByWhitelabel(wlCode).sortedDescendingBy(p -> p.getUpdateDate()).skip(currentPage * pageSize).limit(pageSize);
	}
	
	private JinqStream<ProductEntity> findByWhitelabel(String wlCode){
		int activeFlg = FlagStateEnum.ON.INT_VAL;
		return getJinqStream()
				.where(p -> p.getWlCode().equals(wlCode))
				.where(p -> p.getActiveFlg() == activeFlg);
	}

	@Override
	public int update(long productId, Map<SingularAttribute, Object> updates, String wlCode) {
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		CriteriaUpdate<ProductEntity> cmd = cb.createCriteriaUpdate(ProductEntity.class);
		Root<ProductEntity> root = cmd.from(ProductEntity.class);
		
		if(updates.containsKey(ProductEntity_.name)){
			cmd.set(root.get(ProductEntity_.name), String.valueOf(updates.get(ProductEntity_.name)));
		}
		
		if(updates.containsKey(ProductEntity_.imageName)){
			cmd.set(root.get(ProductEntity_.imageName), String.valueOf(updates.get(ProductEntity_.imageName)));
		}
		
		if(updates.containsKey(ProductEntity_.quantity)){
			cmd.set(root.get(ProductEntity_.quantity), Integer.valueOf(updates.get(ProductEntity_.quantity).toString()));
		}
		
		if(updates.containsKey(ProductEntity_.sellPrice)){
			cmd.set(root.get(ProductEntity_.sellPrice), new BigDecimal(updates.get(ProductEntity_.sellPrice).toString()));
		}
		
		if(updates.containsKey(ProductEntity_.buyPrice)){
			cmd.set(root.get(ProductEntity_.buyPrice), new BigDecimal(updates.get(ProductEntity_.buyPrice).toString()));
		}
		
		if(updates.containsKey(ProductEntity_.hotFlg)){
			cmd.set(root.get(ProductEntity_.hotFlg), Integer.valueOf(updates.get(ProductEntity_.hotFlg).toString()));
		}
		
		if(updates.containsKey(ProductEntity_.newFlg)){
			cmd.set(root.get(ProductEntity_.newFlg), Integer.valueOf(updates.get(ProductEntity_.newFlg).toString()));
		}
		
		if(updates.containsKey(ProductEntity_.promoteFlg)){
			cmd.set(root.get(ProductEntity_.promoteFlg), Integer.valueOf(updates.get(ProductEntity_.promoteFlg).toString()));
		}
		
		if(updates.containsKey(ProductEntity_.description)){
			cmd.set(root.get(ProductEntity_.description), updates.get(ProductEntity_.description).toString());
		}
		
		if(updates.containsKey(ProductEntity_.activeFlg)){
			cmd.set(root.get(ProductEntity_.activeFlg), Integer.valueOf(updates.get(ProductEntity_.activeFlg).toString()));
		}
		
		cmd.set(root.get(ProductEntity_.updateDate), new Timestamp(System.currentTimeMillis()));
		cmd.where(cb.and(
				cb.equal(root.get(ProductEntity_.id), productId),
				cb.equal(root.get(ProductEntity_.activeFlg), FlagStateEnum.ON.INT_VAL),
				cb.equal(root.get(ProductEntity_.wlCode), wlCode)
				));
		
		return getEntityManager().createQuery(cmd).executeUpdate();
	}

	@Override
	public int addProductQuantity(long productId, int quantity, String wlCode) {
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		CriteriaUpdate<ProductEntity> cmd = cb.createCriteriaUpdate(ProductEntity.class);
		Root<ProductEntity> root = cmd.from(ProductEntity.class);
		
		cmd.set(root.get(ProductEntity_.quantity), cb.sum(root.get(ProductEntity_.quantity), Integer.valueOf(quantity)));
		
		cmd.set(root.get(ProductEntity_.updateDate), new Timestamp(System.currentTimeMillis()));
		cmd.where(cb.and(
				cb.equal(root.get(ProductEntity_.id), productId),
				cb.equal(root.get(ProductEntity_.activeFlg), FlagStateEnum.ON.INT_VAL),
				cb.equal(root.get(ProductEntity_.wlCode), wlCode)
				));
		
		return getEntityManager().createQuery(cmd).executeUpdate();
	}
}
