package com.retailshop.db.entity;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCT_CATEGORY")
public class ProductCategoryEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CATEGORY_ID")
	private Long id;
	
	@Column(name="CATEGORY_NAME")
	private String name;
	
	@Column(name="WL_CODE")
	private String wlCode;
	
	@Column(name="ACTIVE_FLG")
	private Integer activeFlg;
	
	@Column(name="INPUT_DATE")
	private Timestamp inputDate;
	
	@Column(name="UPDATE_DATE")
	private Timestamp updateDate;
	
	@ManyToMany
	@JoinTable(name="PRODUCT_CATEGORY_MAPPING", 
		 joinColumns=@JoinColumn(name="CATEGORY_ID"),
		 inverseJoinColumns=@JoinColumn(name="PRODUCT_ID"))
	private List<ProductEntity> products;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWlCode() {
		return wlCode;
	}
	public void setWlCode(String wlCode) {
		this.wlCode = wlCode;
	}
	public Integer getActiveFlg() {
		return activeFlg;
	}
	public void setActiveFlg(Integer activeFlg) {
		this.activeFlg = activeFlg;
	}
	public Timestamp getInputDate() {
		return inputDate;
	}
	public void setInputDate(Timestamp inputDate) {
		this.inputDate = inputDate;
	}
	public Timestamp getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}
	public List<ProductEntity> getProducts() {
		return products;
	}
	public void setProducts(List<ProductEntity> products) {
		this.products = products;
	}
}
