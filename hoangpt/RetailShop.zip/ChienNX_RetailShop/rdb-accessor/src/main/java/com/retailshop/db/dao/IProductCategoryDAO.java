package com.retailshop.db.dao;

import java.util.Map;
import java.util.stream.Stream;

import javax.persistence.metamodel.SingularAttribute;

import com.retailshop.db.entity.ProductEntity;

public interface IProductCategoryDAO<T> extends IBaseDAO<T> {

	Stream<T> findRecentUpdatedProductCategories(String loginWlCode, long currentPage, int pageSize);

	long countRecentUpdatedProductCategories(String loginWlCode);

	int update(long categoryId, Map<SingularAttribute, Object> updates, String loginWlCode);

	Stream<ProductEntity> getProductsBelongToCategory(long categoryId, String loginWlCode, long currentPage,
			int pageSize);

	Stream<ProductEntity> getProductsBelongToCategory(long categoryId, String loginWlCode);
}
