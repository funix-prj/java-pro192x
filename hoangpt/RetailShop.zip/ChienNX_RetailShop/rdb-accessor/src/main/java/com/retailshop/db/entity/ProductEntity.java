package com.retailshop.db.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCT")
public class ProductEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PRODUCT_ID")
	private Long id;
	
	@Column(name="PRODUCT_NAME")
	private String name;
	
	@Column(name="IMAGE_NAME")
	private String imageName;
	
	@Column(name="QUANTITY")
	private Integer quantity;
	
	@Column(name="BUY_PRICE")
	private BigDecimal buyPrice;
	
	@Column(name="SELL_PRICE")
	private BigDecimal sellPrice;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="NEW_FLG")
	private Integer newFlg;
	
	@Column(name="HOT_FLG")
	private Integer hotFlg;
	
	@Column(name="PROMOTE_FLG")
	private Integer promoteFlg;
	
	@Column(name="WL_CODE")
	private String wlCode;
	
	@Column(name="ACTIVE_FLG")
	private Integer activeFlg;
	
	@Column(name="INPUT_DATE")
	private Timestamp inputDate;
	
	@Column(name="UPDATE_DATE")
	private Timestamp updateDate;
	
	@ManyToMany(mappedBy="products")
	private List<ProductCategoryEntity> cates;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public BigDecimal getBuyPrice() {
		return buyPrice;
	}
	public void setBuyPrice(BigDecimal buyPrice) {
		this.buyPrice = buyPrice;
	}
	public BigDecimal getSellPrice() {
		return sellPrice;
	}
	public void setSellPrice(BigDecimal sellPrice) {
		this.sellPrice = sellPrice;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getNewFlg() {
		return newFlg;
	}
	public void setNewFlg(Integer newFlg) {
		this.newFlg = newFlg;
	}
	public Integer getHotFlg() {
		return hotFlg;
	}
	public void setHotFlg(Integer hotFlg) {
		this.hotFlg = hotFlg;
	}
	public Integer getPromoteFlg() {
		return promoteFlg;
	}
	public void setPromoteFlg(Integer promoteFlg) {
		this.promoteFlg = promoteFlg;
	}
	public String getWlCode() {
		return wlCode;
	}
	public void setWlCode(String wlCode) {
		this.wlCode = wlCode;
	}
	
	public Integer getActiveFlg() {
		return activeFlg;
	}
	public void setActiveFlg(Integer activeFlg) {
		this.activeFlg = activeFlg;
	}
	public Timestamp getInputDate() {
		return inputDate;
	}
	public void setInputDate(Timestamp inputDate) {
		this.inputDate = inputDate;
	}
	public Timestamp getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}
	public List<ProductCategoryEntity> getCates() {
		return cates;
	}
	public void setCates(List<ProductCategoryEntity> cates) {
		this.cates = cates;
	}
}
