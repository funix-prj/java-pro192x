package com.retailshop.db.dao.impl;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jinq.jpa.JinqJPAStreamProvider;
import org.jinq.orm.stream.JinqStream;
import org.springframework.beans.factory.annotation.Autowired;

import com.retailshop.db.dao.IBaseDAO;

public class BaseDAO<T> implements IBaseDAO<T>{
	@PersistenceContext
	private EntityManager em;
	
	private Class<T> clazz;

	@Autowired
	private JinqJPAStreamProvider streamProvider;
	
	JinqStream<T> getJinqStream(){
		return streamProvider.streamAll(em, clazz);
	}
	
	EntityManager getEntityManager(){
		return em;
	}
	
	void setClass(Class<T> clazz){
		this.clazz = clazz;
	}
	
	public T findById(Serializable id) {
		return em.find(this.clazz, id);
	}

	public T save(T t) {
		em.persist(t);
		return t;
	}

}
